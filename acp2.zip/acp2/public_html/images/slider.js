var i = 0;

var image = new Array();

image[0] = "1.jpg";

image[1] = "2.jpg";

image[2] = "3.jpg";

image[3] = "images/ronaldo_back_form_football_11414_1920x1080.jpg";

var k = image.length - 1;

function slideimage()
 {
   
 var img = document.getElementById("slide");
   
 img.src = image[i];
   
 if (i < k)
 {
  
      i++;
 
   }
 else
 {
     
   i = 0;

    }
 
   setTimeout("slideimage()", 3500);

}

function addLoadEvent(func) 
{

    var oldonload = window.onload;
 
   if (typeof window.onload != 'function')
 {
    
    window.onload = func;
 
   }
 else
 {
     
   window.onload = function ()
 {
      
      if (oldonload)
 {
              
  oldonload();
  
          }
          
  func();
    
    }
 
   }

}

addLoadEvent(function () {
    slideimage();});